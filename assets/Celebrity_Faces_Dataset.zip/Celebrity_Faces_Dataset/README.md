# Celebrity Faces Dataset

## 17 Celebrities. 100 images per celebrity:

* Angelina Jolie
* Brad Pitt
* Denzel Washington
* Hugh Jackman
* Jennifer Lawrence
* Johnny Depp
* Kate Winslet
* Leonardo DiCaprio
* Megan Fox
* Natalie Portman
* Nicole Kidman
* Robert Downey Jr
* Sandra Bullock
* Scarlett Johansson
* Tom Cruise
* Tom Hanks
* Will Smith
